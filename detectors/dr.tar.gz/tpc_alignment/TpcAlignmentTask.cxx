#include "TpcAlignmentTask.h"
#include "Run.h"
#include <Rtypes.h>
#include <iostream>

using namespace std;
using namespace TpcAlignment;

ClassImp(TpcAlignmentTask);

TpcAlignmentTask::TpcAlignmentTask() : FairTask("TpcAlignmentTask", 1) {}

TpcAlignmentTask::TpcAlignmentTask(bool debugMode)
    : FairTask("TpcAlignmentTask", 1), vDebugMode(debugMode) {}

TpcAlignmentTask::~TpcAlignmentTask() {}

InitStatus TpcAlignmentTask::Init() { return kSUCCESS; }

void TpcAlignmentTask::SetNumberOfCalibration(int val) {
  vNumberOfCalibration = val;
}

void TpcAlignmentTask::Exec(Option_t *opt) {
  Run R(vDebugMode);
  R.LoadA();
  // Minimum x^2
  for (int i = 0; i < vNumberOfCalibration; ++i) {
    R.Calibration("testA.inp");
  }
  R.Measurement("testA.inp", "testA.out");
}

void TpcAlignmentTask::Finish() {}