#ifndef ALIGNMENT_HH
#define ALIGNMENT_HH

#include <cstdio>
#define M_ 4
#define N_ 3
#define L_ 3 * M_
#define LL L_ *L_

namespace TpcAlignment {
/**
 * @brief Процедуры коррекции измеренных точек
 *
 */
class Alignment {
private:
  double A[24 * L_];
  double M[24 * LL];
  double R[24 * L_];
  bool vDebugMode{false};
  const char *vInputFilename;
  const char *vOutputFilename;

public:
  Alignment();
  Alignment(bool debugMode);
  ~Alignment();

  void SetInputFilename(const char *filename);

  void SetOutputFilename(const char *filename);

  /**
   * @brief Обнуление коеффициентов системы уравнений
   *
   */
  void ResetCoefficients();
  void Finish();
  /**
   * @brief
   *
   * @param filename
   * @return bool
   */
  bool LoadA4File(const char *filename = "InputA.dat");
  void SetA2Default();

protected:
  void SaveA2File(const char *filename = "OutputA.dat");

  /**
   * @brief X=P*t+Q - параметрическое задание трека
   *
   * @param n - размерность
   * @param v - массив
   */
  void AddTrack(int n, double *v);

protected:
  int Correct(double *v1, double *v2);
  void SaveCoeff2File(const char *filename = "outAMR.dat");
  /**
   * @brief Print debug message if allowed.
   *
   * @param _Format
   * @param ... - arguments for printf function
   */
  void PrintDebug(char const *const _Format, ...);
  /**
   * @brief Решение системы уравнений
   *
   * @param A
   * @param B
   * @param n
   * @param X
   * @return int
   */
  static int lsolve(double *A, double *B, int n, double *X);
  static double EU3(double *A, double *P);  
  static void SetF(double *f, double x, double y, double z);
};

} // namespace TpcAlignment

#endif