#include "Run.h"
#include "FileHelper.h"
#include <cstdio>
#include <exception>
#include <iostream>
#include <string>

#define MAXn 1000

using namespace std;

namespace TpcAlignment {
Run::Run() {}
Run::Run(bool debugMode) : Alignment(debugMode) {}
Run::~Run() {}
void Run::LoadA() {
  if (!LoadA4File()) {
    SetA2Default();
    SaveA2File();
  }
}

void Run::Calibration(const char *TrackFilename) {

  PrintDebug("Calibration started\n");
  double v[MAXn * 3], v2[3];

  ResetCoefficients();

  FILE *fp;
  float r;
  fp = fopen(TrackFilename, "r");
  if (!FileHelper::FileExists(fp, TrackFilename, "can't open file")) {
    return;
  }

  int PointsInTrack{0}; // Points in Track
  int readNumber = fscanf(fp, "%d", &PointsInTrack);
  if (readNumber == 0) {
    cout << TrackFilename << " : "
         << "wrong format. Can't read number of Points on Track" << '\n';
    return;
  }
  if (PointsInTrack == 0) {
    cout << TrackFilename << " : "
         << "Points on Tracks is 0" << '\n';
    return;
  }
  PrintDebug("track open\n");
  int vLineNumber{0};
  while (!feof(fp)) {
    ++vLineNumber;
    for (int k = 0; k < PointsInTrack; k++) {
      for (int i = 0; i < 3; i++) {
        readNumber = fscanf(fp, "%f", &r);
        if (readNumber == 0) {
          const char *coordinate =
              (i == 0 ? "X"
                      : (i == 1 ? "Y" : (i == 2 ? "Z" : "Unknown coordinate")));
          cout << TrackFilename << " : "
               << "Wrong number on line: " << vLineNumber << ", point: " << k
               << ", coordinate: " << coordinate << '\n';
          fclose(fp);
          return;
        }
        v[k * 3 + i] = r;
      }
      PrintDebug("get point %f %f %f\n", v[k * 3 + 0], v[k * 3 + 1],
                 v[k * 3 + 2]);
    }
    AddTrack(PointsInTrack, v);
    PrintDebug("track close\n");
    fscanf(fp, "\n");
  }
  fclose(fp);
  Finish();
  PrintDebug("Calibration finished\n");
}

void Run::Measurement(const char *inputName, const char *outputName) {
  printf("Measurement started\n");
  FILE *inputStream, *outputStream;
  float r;
  int TrackNumber{0};
  int PointsOnTrack;
  double v1[3] = {1., 0., 0.}, v2[3]; //  ????????

  inputStream = fopen(inputName, "r");
  if (!FileHelper::FileExists(inputStream, inputName, "can't open file")) {
    return;
  }
  outputStream = fopen(outputName, "w");
  if (!FileHelper::FileExists(outputStream, outputName, "can't open file")) {
    return;
  }

  while (!feof(inputStream)) {
    PointsOnTrack =
        FileHelper::ReadPointsOnTrack(inputStream, inputName, "Measurement");
    if (PointsOnTrack == 0) {
      return;
    }
    if (!FileHelper::WritePointsOnTrack(outputStream, PointsOnTrack, outputName,
                                        "Measurement")) {
      return;
    }
    ++TrackNumber;

    PrintDebug("%d track is opened\n", TrackNumber);
    for (int Point = 0; Point < PointsOnTrack; Point++) {
      if (!FileHelper::ReadXYZ(v1[0], v1[1], v1[2], inputStream, inputName,
                               "Measurement", TrackNumber, Point)) {
        fclose(inputStream);
        fclose(outputStream);
        return;
      }

      PrintDebug("get tpoint(x,y,z): (%f, %f, %f)\n", v1[0], v1[1], v1[2]);
      Correct(v1, v2);      
      if (!FileHelper::WriteXYZ(v2[0], v2[1], v2[2], outputStream, outputName,
                                "Measurement", TrackNumber, Point)) {
        fclose(inputStream);
        fclose(outputStream);
        return;
      }
    }
    fscanf(inputStream, "\n");
    fprintf(outputStream, "\n");
    PrintDebug("%d track is closed\n", TrackNumber);
  }
  fclose(inputStream);
  fclose(outputStream);
  PrintDebug("Measurement finished\n");
}
} // namespace TpcAlignment