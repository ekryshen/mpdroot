#include "MyTask.h"
#include <iostream>
#include <Rtypes.h>

using namespace std;

ClassImp(MyTask);

MyTask::MyTask()
{
   cout << "***********" << '\n';
   cout << " Default Constructor" << '\n';
}

MyTask::MyTask(const char * name):
FairTask(name, 1)
{
      cout << "***********" << '\n';
      cout << "  Constructor: " << name << '\n';
}

MyTask::~MyTask()
{
   cout << "Destructor" << '\n';
   cout << "***********" << '\n';
}

InitStatus MyTask::Init()
{
   cout << "Init" << '\n';
   return kSUCCESS;
}

void MyTask::Exec(Option_t *opt)
{
   cout << "Execute" << '\n';
}

void MyTask::Finish()
{
   cout << "Finish" << '\n';
}