//-----------------------------------------------------------
// File and Version Information:
// $Id$
//
// Description:
//      MyTask is a training task
//
// Environment:
//      Developed for the NICA's MPD.
//
// Author List:
//      Starchenko
//
//
//-----------------------------------------------------------

#ifndef MYTASK_HH
#define MYTASK_HH

#include "FairTask.h"
// #include "Rtypes.h"       // ClasDef/ClassImp macro
// #include "RtypesCore.h"  // Option_t

class MyTask : public FairTask
{
public:
   MyTask();
   MyTask(const char * name);
   virtual ~MyTask();

   virtual InitStatus Init() override;
   void  Exec(Option_t *opt = "") override;
   virtual void  Finish() override;
 public:
   ClassDef(MyTask, 1);
};

#endif